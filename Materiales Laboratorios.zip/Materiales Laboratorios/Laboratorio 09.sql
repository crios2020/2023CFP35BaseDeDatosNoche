-- Uso de JOIN

-- Usando la base de datos negocio2 (usando todas las tablas).

-- 1- Informar quienes (nombre,apellido) compraron 'lamparas'.
-- 2- Informar que articulos compro 'Juan Perez'.
-- 3- Informar cuantas lamparas se vendieron.
-- 4- Informar cuantas unidades se vendieron en total en cada articulo.
-- 5- Informar la lista de artículos vendidos el día de hoy.
-- 6- Informar la lista de artículos vendidos en este mes.
-- 7- Informar la lista de artículos vendidos en este año y la cantidad vendida.


