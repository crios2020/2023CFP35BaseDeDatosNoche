
-- 1- Borrar si existe la base de datos Agenda.

-- 2- Crear la base de datos Agenda.

-- 3- Ingresar a la base de datos creada.

-- 4- Crear una tabla llamada "agenda". Debe tener los siguientes campos:

--    nombre (cadena de 20), 
--    domicilio (cadena de 30)
--    telefono (cadena de 11)

-- 5- Visualizar las tablas existentes en la base de datos para verificar la creación de "agenda".

-- 6- Visualizar la estructura de campos de la tabla "agenda". (describe).

-- 7- Ingresar 10 registros con valores aleatorios.

-- 8- Seleccione y muestre todos los registros de la tabla:

-- Felicitaciones usted ha armado su agenda personal!!!!
