drop database if exists clase02;
create database clase02;
use clase02;
show databases;

/*
-- no podemos ejecutar esto, por que no tenemos la BD herramientas
use herramientasCFP35;
show tables;
select * from herramientas;
delete from herramientas where id=453;
describe herramientas;
*/

show tables;

-- Creamos una tabla
create table clientes(
	codigo integer auto_increment primary key, 
    nombre varchar(20) not null,   
    apellido varchar(20) not null,
    cuit char(11),
    direccion varchar(50),
    comentarios varchar(255)
);

insert into clientes 	(nombre, apellido, cuit, direccion) values
						('Juan', 'Correti', '123456789', 'Lima 222');

INSERT INTO clientes (nombre, apellido, cuit, direccion, comentarios) VALUES
  ('Juan', 'Gomez', '20345678901', 'Calle 123', 'Cliente regular'),
  ('María', 'López', '30456789012', 'Avenida 456', 'Nuevo cliente'),
  ('Pedro', 'Martínez', '40567890123', 'Calle Principal', 'Cliente preferente'),
  ('Laura', 'Rodríguez', '50678901234', 'Avenida Central', 'Cliente VIP'),
  ('Carlos', 'Fernández', '60789012345', 'Calle Secundaria', 'Cliente ocasional'),
  ('Ana', 'Pérez', '70890123456', 'Avenida 789', 'Cliente frecuente'),
  ('Miguel', 'González', '80901234567', 'Calle 456', 'Cliente nuevo'),
  ('Sofía', 'Ramírez', '91012345678', 'Avenida 123', 'Cliente importante'),
  ('Diego', 'Silva', '01123456789', 'Calle 789', 'Cliente regular'),
  ('Carolina', 'Torres', '12134567890', 'Avenida 234', 'Cliente preferente'),
  ('José', 'Hernández', '23145678901', 'Calle Principal', 'Cliente frecuente'),
  ('Andrea', 'Paz', '34156789012', 'Avenida Central', 'Cliente nuevo'),
  ('Mario', 'Moreno', '45167890123', 'Calle Secundaria', 'Cliente VIP'),
  ('Fernanda', 'Rojas', '56178901234', 'Avenida 456', 'Cliente importante'),
  ('Javier', 'García', '67189012345', 'Calle 789', 'Cliente frecuente'),
  ('Gabriela', 'Luna', '78190123456', 'Avenida 123', 'Cliente ocasional'),
  ('Luis', 'Vargas', '89101234567', 'Calle 234', 'Cliente preferente'),
  ('Carla', 'Cruz', '90112345678', 'Avenida 789', 'Cliente regular'),
  ('Ricardo', 'Santos', '01123456789', 'Calle Principal', 'Cliente nuevo'),
  ('Valeria', 'Ortega', '12134567890', 'Avenida Central', 'Cliente VIP'),
  ('Daniel', 'Mendoza', '23145678901', 'Calle Secundaria', 'Cliente importante'),
  ('Lucía', 'Guerrero', '34156789012', 'Avenida 456', 'Cliente frecuente'),
  ('Pablo', 'Navarro', '45167890123', 'Calle 789', 'Cliente nuevo'),
  ('Alejandra', 'Ríos', '56178901234', 'Avenida 123', 'Cliente preferente'),
  ('Hugo', 'Cordero', '67189012345', 'Calle 234', 'Cliente ocasional');                        

INSERT INTO clientes (nombre, apellido, cuit, direccion, comentarios) VALUES
  ('Giovanni', 'Rossi', '20345678901', 'Via Roma 123', 'Cliente regular'),
  ('Francesca', 'Bianchi', '30456789012', 'Piazza Dante 456', 'Nuevo cliente'),
  ('Antonio', 'Ferrari', '40567890123', 'Corso Italia 789', 'Cliente preferente'),
  ('Maria', 'Ricci', '50678901234', 'Via Verdi 234', 'Cliente VIP'),
  ('Marco', 'Marini', '60789012345', 'Largo Garibaldi 567', 'Cliente ocasional'),
  ('Luca', 'Conti', '70890123456', 'Via Milano 890', 'Cliente frecuente'),
  ('Alessia', 'Galli', '80901234567', 'Piazza Garibaldi 123', 'Cliente nuevo'),
  ('Simone', 'Moretti', '91012345678', 'Corso Vittorio Emanuele 456', 'Cliente importante'),
  ('Giulia', 'Barbieri', '01123456789', 'Via Dante 789', 'Cliente regular'),
  ('Matteo', 'Mancini', '12134567890', 'Piazza San Pietro 012', 'Cliente preferente'),
  ('Sara', 'Leone', '23145678901', 'Corso Umberto 345', 'Cliente frecuente'),
  ('Lorenzo', 'Rizzo', '34156789012', 'Via Garibaldi 678', 'Cliente nuevo');
  
INSERT INTO clientes (nombre, apellido, cuit, direccion, comentarios) VALUES
  ('Aleksandr', 'Ivanov', '20345678901', 'ul. Lenina 123', 'Cliente regular'),
  ('Elena', 'Kovač', '30456789012', 'Trg Slobode 456', 'Nuevo cliente'),
  ('Mihai', 'Popescu', '40567890123', 'Strada Victoriei 789', 'Cliente preferente'),
  ('Anastasia', 'Kuznetsova', '50678901234', 'ul. Gorkogo 234', 'Cliente VIP'),
  ('Pavel', 'Novák', '60789012345', 'Náměstí Republiky 567', 'Cliente ocasional');

select * from clientes;



-- -----------------------------------
-- Tipos de datos más comunes en MySQL
-- -----------------------------------

-- Tipo de datos Texto de datos más comunes

-- Tipo		Bytes de almacenamiento
-- _______________________________________
-- char(x)		x
-- varchar(x)	x+1

/*
	nombre char(20),
    |ANA                 |			20 bytes
    |CARLOS              |			20 bytes
    |MAXIMILIANO         |   		20 bytes
						Total:		60 bytes
	
    nombre varchar(20)
    |ANA                 |			 3 + 1 = 4 bytes
    |CARLOS              |			 6 + 1 = 7 bytes
    |MAXIMILIANO         | 			11 + 1 =12 bytes
						Total:		23 bytes
                        
*/


-- Tipo de datos Numérico

-- Tipo		Bytes de almacenamiento
-- _______________________________________
-- bool (boolean)	1	(0 es false distinto de 0 es true)			Java
-- tinyint			1	2^8			256								byte
-- smallint			2	2^16		65536							short
-- mediumint		3	2^24		16777216
-- int (integer)	4	2^32		4294967296						int
-- bigint			8	2^64		18446744073709551616			long
-- float			4	 											float
-- double			8												double
-- decimal(t,d)		t+2 											BigDecimal

/*
		codigo tinyint,
		codigo tinyint signed,
       
        
        |--------|--------|
	  -128       0       127
      
		codigo tinyint unsigned
        
        |-----------------|
        0				 255
	
		1/3
      float 32 bits
      .3333333
      --------
      
      double 64 bits
      .333333333333333
      ----------------
      
      10/3
      float 32 bits
      3.333333
      --------
      
      double 64 bits
      3.33333333333333
      ----------------
      
      100/3
      float 32 bits
      33.33333
      --------
      
      double 64 bits
      33.3333333333333
      ----------------
      
      precio decimal(7,2)			// 7 + 2 = 9
      99999,99
      -----,--
      
      precio decimal(7,3)			// 7 + 2 = 9
      9999,999
      ----,---
      
*/

-- Tipo de datos Fecha y Hora

-- Tipo		Bytes de almacenamiento
-- _______________________________________
-- date		3	Año Mes Dia '2023-10-12'		'2023/10/12'
-- datetime	8
-- time		3
-- year		1

select 'Hola Mundo!!';
select 2+2;

-- uso del alias
select 2+2 as 'total';
select 2+2 'total';
select pi() PI;
select curdate() 'fecha_actual';			-- fecha del server
select curtime() 'hora_actual'; 			-- hora del server
select sysdate() 'fecha_hora_actual';
select day(curdate()) 'dia';
select month(curdate()) 'mes';
select year(curdate()) 'año';






