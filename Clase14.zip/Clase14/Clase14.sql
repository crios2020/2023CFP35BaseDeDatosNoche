-- Active: 1699112345571@@127.0.0.1@3306@colegio
show databases;
use negocio;
show tables;
describe facturas;
describe articulos;
-- Creamos la tabla detalles
create table detalles(
    letra char(1) not null,
    numero int not null,
    codigo int not null,
    cantidad int not null
);

describe detalles;

-- Declaramos las constraint de Foreign Key de la tabla detalles
alter table detalles
    add constraint FK_Detalles_Facturas
    foreign key(letra,numero)
    references facturas(letra,numero);

alter table detalles
    add constraint FK_Detalles_Articulos
    foreign key(codigo)
    references articulos(codigo);

select * from clientes;
select * from facturas;
select * from articulos;
select * from detalles;
-- insert into detalles values ('B',44,9999,19); -- no cumple con la integridad referencial

insert into detalles values 
    ('A',1,1,20),
    ('A',1,2,22),
    ('A',2,5,20),
    ('A',2,6,26),
    ('A',3,1,2),
    ('A',3,3,20);

insert into detalles values 
    ('B',1,6,20),
    ('B',1,7,22),
    ('B',2,9,20),
    ('C',2,6,26),
    ('C',3,4,2),
    ('C',3,5,20);

insert into detalles values 
    ('B',1,1,20);

-- consulta del producto carteriano
select * from clientes, facturas, detalles, articulos;
select count(*) cantidad from clientes;             -- 65
select count(*) cantidad from facturas;             -- 50
select count(*) cantidad from detalles;             --  6
select count(*) cantidad from articulos;            -- 20
select 65*50*6*20;                                  -- 390000
select count(*) cantidad from clientes, facturas, detalles, articulos;  -- 390000

-- consulta del producto relacionado
select * from clientes c join facturas f on c.codigo=f.codigoCliente
        join detalles d on f.letra=d.letra and f.numero=d.numero
        join articulos a on d.codigo=a.codigo;

-- Que articulos compro Juan Perez?
select a.codigo, a.descripcion, a.precio
        from clientes c join facturas f on c.codigo=f.codigoCliente
        join detalles d on f.letra=d.letra and f.numero=d.numero
        join articulos a on d.codigo=a.codigo
        where c.nombre='Juan' and c.apellido='Perez';

-- Quienes compraron 'Martillo de carpintero'?
select DISTINCT c.codigo, c.nombre, c.apellido
        from clientes c join facturas f on c.codigo=f.codigoCliente
        join detalles d on f.letra=d.letra and f.numero=d.numero
        join articulos a on d.codigo=a.codigo
        where a.descripcion='Martillo de carpintero';

