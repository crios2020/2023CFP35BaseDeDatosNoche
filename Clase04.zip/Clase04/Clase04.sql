drop database if exists negocio;
create database negocio;
use negocio;
create table clientes(
	codigo integer auto_increment primary key, 					-- campo clave - primary key
    nombre varchar(20) not null,   
    apellido varchar(20) not null,
    cuit char(11),												-- campo clave candidata
    direccion varchar(50),
    comentarios varchar(255)
);
create table facturas(
	letra char(1),												
    numero int,
    fecha date,
    monto double,
    primary key(letra,numero) 									-- clave primaria compuesta
);
-- Clave primaria compuesta. 
create table articulos(
	codigo int primary key,
    descripcion varchar(150) not null,
    precio double,
    stock int
);
show tables;
describe clientes;
describe facturas;
describe articulos;

INSERT INTO clientes (nombre, apellido, cuit, direccion, comentarios) VALUES
('Juan', 'Pérez', '12345678901', 'Calle 123', 'Cliente frecuente'),
('María', 'Gómez', '23456789012', 'Avenida 456', 'Cliente nuevo'),
('Carlos', 'López', '34567890123', 'Plaza Principal', ''),
('Laura', 'Martínez', '45678901234', 'Calle 789', ''),
('Pedro', 'Rodríguez', '56789012345', 'Avenida 012', ''),
('Ana', 'Hernández', '67890123456', 'Calle 345', ''),
('Luis', 'García', '78901234567', 'Avenida 678', ''),
('Silvia', 'Fernández', '89012345678', 'Calle 901', ''),
('Diego', 'Torres', '90123456789', 'Avenida 234', ''),
('Marta', 'Sánchez', '01234567890', 'Calle 567', ''),
('Roberto', 'Romero', '12345678901', 'Avenida 890', ''),
('Elena', 'Ortega', '23456789012', 'Calle 123', ''),
('Andrés', 'Vargas', '34567890123', 'Avenida 456', ''),
('Carolina', 'Molina', '45678901234', 'Calle 789', ''),
('Fernando', 'Rojas', '56789012345', 'Avenida 012', ''),
('Gabriela', 'Paredes', '67890123456', 'Calle 345', ''),
('Héctor', 'Navarro', '78901234567', 'Avenida 678', ''),
('Lucía', 'Sosa', '89012345678', 'Calle 901', ''),
('Ricardo', 'Cabrera', '90123456789', 'Avenida 234', ''),
('Natalia', 'Ríos', '01234567890', 'Calle 567', '');


insert into clientes 	(nombre, apellido, cuit, direccion) values
						('Juan', 'Correti', '123456789', 'Lima 222');

INSERT INTO clientes (nombre, apellido, cuit, direccion, comentarios) VALUES
  ('Juan', 'Gomez', '20345678901', 'Calle 123', 'Cliente regular'),
  ('María', 'López', '30456789012', 'Avenida 456', 'Nuevo cliente'),
  ('Pedro', 'Martínez', '40567890123', 'Calle Principal', 'Cliente preferente'),
  ('Laura', 'Rodríguez', '50678901234', 'Avenida Central', 'Cliente VIP'),
  ('Carlos', 'Fernández', '60789012345', 'Calle Secundaria', 'Cliente ocasional'),
  ('Ana', 'Pérez', '70890123456', 'Avenida 789', 'Cliente frecuente'),
  ('Miguel', 'González', '80901234567', 'Calle 456', 'Cliente nuevo'),
  ('Sofía', 'Ramírez', '91012345678', 'Avenida 123', 'Cliente importante'),
  ('Diego', 'Silva', '01123456789', 'Calle 789', 'Cliente regular'),
  ('Carolina', 'Torres', '12134567890', 'Avenida 234', 'Cliente preferente'),
  ('José', 'Hernández', '23145678901', 'Calle Principal', 'Cliente frecuente'),
  ('Andrea', 'Paz', '34156789012', 'Avenida Central', 'Cliente nuevo'),
  ('Mario', 'Moreno', '45167890123', 'Calle Secundaria', 'Cliente VIP'),
  ('Fernanda', 'Rojas', '56178901234', 'Avenida 456', 'Cliente importante'),
  ('Javier', 'García', '67189012345', 'Calle 789', 'Cliente frecuente'),
  ('Gabriela', 'Luna', '78190123456', 'Avenida 123', 'Cliente ocasional'),
  ('Luis', 'Vargas', '89101234567', 'Calle 234', 'Cliente preferente'),
  ('Carla', 'Cruz', '90112345678', 'Avenida 789', 'Cliente regular'),
  ('Ricardo', 'Santos', '01123456789', 'Calle Principal', 'Cliente nuevo'),
  ('Valeria', 'Ortega', '12134567890', 'Avenida Central', 'Cliente VIP'),
  ('Daniel', 'Mendoza', '23145678901', 'Calle Secundaria', 'Cliente importante'),
  ('Lucía', 'Guerrero', '34156789012', 'Avenida 456', 'Cliente frecuente'),
  ('Pablo', 'Navarro', '45167890123', 'Calle 789', 'Cliente nuevo'),
  ('Alejandra', 'Ríos', '56178901234', 'Avenida 123', 'Cliente preferente'),
  ('Hugo', 'Cordero', '67189012345', 'Calle 234', 'Cliente ocasional');                        

INSERT INTO clientes (nombre, apellido, cuit, direccion, comentarios) VALUES
  ('Giovanni', 'Rossi', '20345678901', 'Via Roma 123', 'Cliente regular'),
  ('Francesca', 'Bianchi', '30456789012', 'Piazza Dante 456', 'Nuevo cliente'),
  ('Antonio', 'Ferrari', '40567890123', 'Corso Italia 789', 'Cliente preferente'),
  ('Maria', 'Ricci', '50678901234', 'Via Verdi 234', 'Cliente VIP'),
  ('Marco', 'Marini', '60789012345', 'Largo Garibaldi 567', 'Cliente ocasional'),
  ('Luca', 'Conti', '70890123456', 'Via Milano 890', 'Cliente frecuente'),
  ('Alessia', 'Galli', '80901234567', 'Piazza Garibaldi 123', 'Cliente nuevo'),
  ('Simone', 'Moretti', '91012345678', 'Corso Vittorio Emanuele 456', 'Cliente importante'),
  ('Giulia', 'Barbieri', '01123456789', 'Via Dante 789', 'Cliente regular'),
  ('Matteo', 'Mancini', '12134567890', 'Piazza San Pietro 012', 'Cliente preferente'),
  ('Sara', 'Leone', '23145678901', 'Corso Umberto 345', 'Cliente frecuente'),
  ('Lorenzo', 'Rizzo', '34156789012', 'Via Garibaldi 678', 'Cliente nuevo');
  
INSERT INTO clientes (nombre, apellido, cuit, direccion, comentarios) VALUES
  ('Aleksandr', 'Ivanov', '20345678901', 'ul. Lenina 123', 'Cliente regular'),
  ('Elena', 'Kovač', '30456789012', 'Trg Slobode 456', 'Nuevo cliente'),
  ('Mihai', 'Popescu', '40567890123', 'Strada Victoriei 789', 'Cliente preferente'),
  ('Anastasia', 'Kuznetsova', '50678901234', 'ul. Gorkogo 234', 'Cliente VIP'),
  ('Pavel', 'Novák', '60789012345', 'Náměstí Republiky 567', 'Cliente ocasional');

INSERT INTO facturas (letra, numero, fecha, monto) VALUES
('A', 1, '2023-01-01', 100.50),
('A', 2, '2023-01-02', 200.75),
('A', 3, '2023-01-03', 150.25),
('A', 4, '2023-01-04', 300.00),
('B', 1, '2023-01-01', 50.75),
('B', 2, '2023-01-02', 75.25),
('B', 3, '2023-01-03', 125.50),
('B', 4, '2023-01-04', 250.00),
('C', 1, '2023-01-01', 75.25),
('C', 2, '2023-01-02', 150.50),
('C', 3, '2023-01-03', 200.75),
('C', 4, '2023-01-04', 100.25),
('D', 1, '2023-01-01', 300.00),
('D', 2, '2023-01-02', 100.50),
('D', 3, '2023-01-03', 200.75),
('D', 4, '2023-01-04', 150.25),
('E', 1, '2023-01-01', 250.00),
('E', 2, '2023-01-02', 50.75),
('E', 3, '2023-01-03', 75.25),
('E', 4, '2023-01-04', 125.50);

INSERT INTO facturas (letra, numero, fecha, monto) VALUES
('A', 100, '2022-01-01', 100.50),
('A', 200, '2022-01-02', 200.75),
('A', 300, '2022-01-03', 150.25),
('A', 400, '2022-01-04', 300.00),
('B', 100, '2022-01-01', 50.75),
('B', 200, '2022-01-02', 75.25),
('B', 300, '2022-01-03', 125.50),
('B', 400, '2022-01-04', 250.00),
('C', 100, '2022-01-01', 75.25),
('C', 200, '2022-01-02', 150.50),
('C', 300, '2022-01-03', 200.75),
('C', 400, '2022-01-04', 100.25),
('D', 100, '2022-01-01', 300.00),
('D', 200, '2022-01-02', 100.50),
('D', 300, '2022-01-03', 200.75),
('D', 400, '2022-01-04', 150.25),
('E', 1010, '2022-01-01', 250.00),
('E', 201, '2022-01-02', 50.75),
('E', 301, '2022-01-03', 75.25),
('E', 41, '2022-01-04', 125.50);

INSERT INTO articulos (codigo, descripcion, precio, stock) VALUES
(1, 'Martillo de carpintero', 12.99, 50),
(2, 'Destornillador Phillips', 6.99, 70),
(3, 'Cinta métrica de acero', 8.50, 100),
(4, 'Llave inglesa ajustable', 10.99, 40),
(5, 'Sierra para metales', 18.50, 80),
(6, 'Taladro eléctrico inalámbrico', 79.99, 60),
(7, 'Broca de concreto de 10 mm', 5.99, 120),
(8, 'Pala de jardín', 14.99, 30),
(9, 'Cincel para tallar madera', 9.99, 90),
(10, 'Guantes de trabajo resistentes', 12.99, 40),
(11, 'Llave de tubo de 12 pulgadas', 14.50, 70),
(12, 'Serrucho de mano', 16.99, 50),
(13, 'Clavos galvanizados de 2 pulgadas', 7.99, 110),
(14, 'Pistola de silicona caliente', 11.99, 20),
(15, 'Escalera de aluminio de 6 pies', 39.99, 60),
(16, 'Tornillos para madera de 2-1/2 pulgadas', 9.50, 80),
(17, 'Candado de seguridad resistente', 8.99, 100),
(18, 'Pintura en aerosol color negro mate', 5.99, 30),
(19, 'Flexómetro retráctil de 5 metros', 12.50, 70),
(20, 'Cepillo de alambre de acero', 7.99, 90);

show tables;
describe clientes;
describe facturas;
describe articulos;
select * from clientes;
select * from facturas;
select * from articulos;

drop table if exists morosos;
create table morosos(
	nombre varchar(20),
    apellido varchar(20)
);

insert into morosos values 
	('Carlos','López'),('Diego','Perez'),
	('Juan','Pérez'),('Laura','Torres');
insert into morosos values ('Ana','Hernandez');
select * from morosos;

-- Listar todos los clientes que no son morosos

select * from clientes where nombre='Carlos' and apellido='López';		-- id=3
select * from clientes where nombre='Diego' and apellido='Perez';		-- no existe
select * from clientes where nombre='Juan' and apellido='Pérez'; 		-- id=1
select * from clientes where nombre='Laura' and apellido='Torres'; 		-- no existe
-- existen 2 morosos

select * from clientes;						-- hay 63 clientes
select count(*) cantidad from clientes;		-- hay 63 clientes

-- resta de consultas
-- select * from clientes 
-- 	where nombre not in(select nombre from morosos) 
--    and apellido not in(select apellido from morosos);

-- solución, todavía no estudiamos JOIN
SELECT * FROM clientes c LEFT JOIN morosos m
ON c.nombre = m.nombre AND c.apellido = m.apellido
WHERE m.nombre IS NULL AND m.apellido IS NULL;

-- Gustavo (más optima)
SELECT *
FROM clientes
WHERE (nombre, apellido) NOT IN (SELECT nombre, apellido FROM morosos);

-- chat GPT
SELECT nombre, apellido, direccion
FROM clientes
WHERE CONCAT(nombre, apellido) NOT IN (
    SELECT CONCAT(nombre, apellido)
    FROM morosos
);

-- valores null (desconocido)
insert into clientes (nombre,apellido,direccion) values 
	('Ana','Mendoza',null),('David','Garcia','');

insert into articulos (codigo,descripcion,precio) values
	(5001,'Lampara led 10W',null),(5002,'Lampara led 8W',0);

select * from clientes where direccion is null;
select * from clientes where direccion is not null;
-- select * from clientes where direccion =null;
select * from clientes where direccion='';

insert into clientes (nombre,apellido) values
('Mario','Rodriguez'), ('Marta','Rodriguez'), 
('Mariano','Rodriguez'), ('Marcia','Rodriguez'), 
('Magali','Rodriguez'), ('Micaela','Rodriguez'), 
('Monica','Rodriguez'), ('Mercedes','Rodriguez'), 
('Melina','Rodriguez'), ('Omar','Rodriguez'),
('Mirta','Rodriguez'), ('Armando','Rodriguez'), 
('Maria','Rodriguez'), ('Marcela','Rodriguez');
insert into clientes (nombre,apellido,direccion) values 
('Andres','Perez','av. Lima 345');

-- busqueda de expresiones
-- uso de like y not like
select * from clientes where nombre like 'm%';
select * from clientes where nombre not like 'm%';
select * from clientes where nombre like 'ma%';
select * from clientes where nombre like 'mar%';
select * from clientes where nombre like '%a';
select * from clientes where nombre like '%ar%';
select * from clientes where nombre like 'm%a';
select * from clientes where nombre like 'a%' and apellido like '%z';
select * from clientes where apellido like '%perez%' and direccion like '%lima%';
select * from clientes where nombre like 'm_r%';		-- autor like '%bor_es%'
drop database if exists negocio;
create database negocio;
use negocio;
create table clientes(
	codigo integer auto_increment primary key, 					-- campo clave - primary key
    nombre varchar(20) not null,   
    apellido varchar(20) not null,
    cuit char(11),												-- campo clave candidata
    direccion varchar(50),
    comentarios varchar(255)
);
create table facturas(
	letra char(1),												
    numero int,
    fecha date,
    monto double,
    primary key(letra,numero) 									-- clave primaria compuesta
);
-- Clave primaria compuesta. 
create table articulos(
	codigo int primary key,
    descripcion varchar(150) not null,
    precio double,
    stock int
);
show tables;
describe clientes;
describe facturas;
describe articulos;

INSERT INTO clientes (nombre, apellido, cuit, direccion, comentarios) VALUES
('Juan', 'Pérez', '12345678901', 'Calle 123', 'Cliente frecuente'),
('María', 'Gómez', '23456789012', 'Avenida 456', 'Cliente nuevo'),
('Carlos', 'López', '34567890123', 'Plaza Principal', ''),
('Laura', 'Martínez', '45678901234', 'Calle 789', ''),
('Pedro', 'Rodríguez', '56789012345', 'Avenida 012', ''),
('Ana', 'Hernández', '67890123456', 'Calle 345', ''),
('Luis', 'García', '78901234567', 'Avenida 678', ''),
('Silvia', 'Fernández', '89012345678', 'Calle 901', ''),
('Diego', 'Torres', '90123456789', 'Avenida 234', ''),
('Marta', 'Sánchez', '01234567890', 'Calle 567', ''),
('Roberto', 'Romero', '12345678901', 'Avenida 890', ''),
('Elena', 'Ortega', '23456789012', 'Calle 123', ''),
('Andrés', 'Vargas', '34567890123', 'Avenida 456', ''),
('Carolina', 'Molina', '45678901234', 'Calle 789', ''),
('Fernando', 'Rojas', '56789012345', 'Avenida 012', ''),
('Gabriela', 'Paredes', '67890123456', 'Calle 345', ''),
('Héctor', 'Navarro', '78901234567', 'Avenida 678', ''),
('Lucía', 'Sosa', '89012345678', 'Calle 901', ''),
('Ricardo', 'Cabrera', '90123456789', 'Avenida 234', ''),
('Natalia', 'Ríos', '01234567890', 'Calle 567', '');


insert into clientes 	(nombre, apellido, cuit, direccion) values
						('Juan', 'Correti', '123456789', 'Lima 222');

INSERT INTO clientes (nombre, apellido, cuit, direccion, comentarios) VALUES
  ('Juan', 'Gomez', '20345678901', 'Calle 123', 'Cliente regular'),
  ('María', 'López', '30456789012', 'Avenida 456', 'Nuevo cliente'),
  ('Pedro', 'Martínez', '40567890123', 'Calle Principal', 'Cliente preferente'),
  ('Laura', 'Rodríguez', '50678901234', 'Avenida Central', 'Cliente VIP'),
  ('Carlos', 'Fernández', '60789012345', 'Calle Secundaria', 'Cliente ocasional'),
  ('Ana', 'Pérez', '70890123456', 'Avenida 789', 'Cliente frecuente'),
  ('Miguel', 'González', '80901234567', 'Calle 456', 'Cliente nuevo'),
  ('Sofía', 'Ramírez', '91012345678', 'Avenida 123', 'Cliente importante'),
  ('Diego', 'Silva', '01123456789', 'Calle 789', 'Cliente regular'),
  ('Carolina', 'Torres', '12134567890', 'Avenida 234', 'Cliente preferente'),
  ('José', 'Hernández', '23145678901', 'Calle Principal', 'Cliente frecuente'),
  ('Andrea', 'Paz', '34156789012', 'Avenida Central', 'Cliente nuevo'),
  ('Mario', 'Moreno', '45167890123', 'Calle Secundaria', 'Cliente VIP'),
  ('Fernanda', 'Rojas', '56178901234', 'Avenida 456', 'Cliente importante'),
  ('Javier', 'García', '67189012345', 'Calle 789', 'Cliente frecuente'),
  ('Gabriela', 'Luna', '78190123456', 'Avenida 123', 'Cliente ocasional'),
  ('Luis', 'Vargas', '89101234567', 'Calle 234', 'Cliente preferente'),
  ('Carla', 'Cruz', '90112345678', 'Avenida 789', 'Cliente regular'),
  ('Ricardo', 'Santos', '01123456789', 'Calle Principal', 'Cliente nuevo'),
  ('Valeria', 'Ortega', '12134567890', 'Avenida Central', 'Cliente VIP'),
  ('Daniel', 'Mendoza', '23145678901', 'Calle Secundaria', 'Cliente importante'),
  ('Lucía', 'Guerrero', '34156789012', 'Avenida 456', 'Cliente frecuente'),
  ('Pablo', 'Navarro', '45167890123', 'Calle 789', 'Cliente nuevo'),
  ('Alejandra', 'Ríos', '56178901234', 'Avenida 123', 'Cliente preferente'),
  ('Hugo', 'Cordero', '67189012345', 'Calle 234', 'Cliente ocasional');                        

INSERT INTO clientes (nombre, apellido, cuit, direccion, comentarios) VALUES
  ('Giovanni', 'Rossi', '20345678901', 'Via Roma 123', 'Cliente regular'),
  ('Francesca', 'Bianchi', '30456789012', 'Piazza Dante 456', 'Nuevo cliente'),
  ('Antonio', 'Ferrari', '40567890123', 'Corso Italia 789', 'Cliente preferente'),
  ('Maria', 'Ricci', '50678901234', 'Via Verdi 234', 'Cliente VIP'),
  ('Marco', 'Marini', '60789012345', 'Largo Garibaldi 567', 'Cliente ocasional'),
  ('Luca', 'Conti', '70890123456', 'Via Milano 890', 'Cliente frecuente'),
  ('Alessia', 'Galli', '80901234567', 'Piazza Garibaldi 123', 'Cliente nuevo'),
  ('Simone', 'Moretti', '91012345678', 'Corso Vittorio Emanuele 456', 'Cliente importante'),
  ('Giulia', 'Barbieri', '01123456789', 'Via Dante 789', 'Cliente regular'),
  ('Matteo', 'Mancini', '12134567890', 'Piazza San Pietro 012', 'Cliente preferente'),
  ('Sara', 'Leone', '23145678901', 'Corso Umberto 345', 'Cliente frecuente'),
  ('Lorenzo', 'Rizzo', '34156789012', 'Via Garibaldi 678', 'Cliente nuevo');
  
INSERT INTO clientes (nombre, apellido, cuit, direccion, comentarios) VALUES
  ('Aleksandr', 'Ivanov', '20345678901', 'ul. Lenina 123', 'Cliente regular'),
  ('Elena', 'Kovač', '30456789012', 'Trg Slobode 456', 'Nuevo cliente'),
  ('Mihai', 'Popescu', '40567890123', 'Strada Victoriei 789', 'Cliente preferente'),
  ('Anastasia', 'Kuznetsova', '50678901234', 'ul. Gorkogo 234', 'Cliente VIP'),
  ('Pavel', 'Novák', '60789012345', 'Náměstí Republiky 567', 'Cliente ocasional');

INSERT INTO facturas (letra, numero, fecha, monto) VALUES
('A', 1, '2023-01-01', 100.50),
('A', 2, '2023-01-02', 200.75),
('A', 3, '2023-01-03', 150.25),
('A', 4, '2023-01-04', 300.00),
('B', 1, '2023-01-01', 50.75),
('B', 2, '2023-01-02', 75.25),
('B', 3, '2023-01-03', 125.50),
('B', 4, '2023-01-04', 250.00),
('C', 1, '2023-01-01', 75.25),
('C', 2, '2023-01-02', 150.50),
('C', 3, '2023-01-03', 200.75),
('C', 4, '2023-01-04', 100.25),
('D', 1, '2023-01-01', 300.00),
('D', 2, '2023-01-02', 100.50),
('D', 3, '2023-01-03', 200.75),
('D', 4, '2023-01-04', 150.25),
('E', 1, '2023-01-01', 250.00),
('E', 2, '2023-01-02', 50.75),
('E', 3, '2023-01-03', 75.25),
('E', 4, '2023-01-04', 125.50);

INSERT INTO facturas (letra, numero, fecha, monto) VALUES
('A', 100, '2022-01-01', 100.50),
('A', 200, '2022-01-02', 200.75),
('A', 300, '2022-01-03', 150.25),
('A', 400, '2022-01-04', 300.00),
('B', 100, '2022-01-01', 50.75),
('B', 200, '2022-01-02', 75.25),
('B', 300, '2022-01-03', 125.50),
('B', 400, '2022-01-04', 250.00),
('C', 100, '2022-01-01', 75.25),
('C', 200, '2022-01-02', 150.50),
('C', 300, '2022-01-03', 200.75),
('C', 400, '2022-01-04', 100.25),
('D', 100, '2022-01-01', 300.00),
('D', 200, '2022-01-02', 100.50),
('D', 300, '2022-01-03', 200.75),
('D', 400, '2022-01-04', 150.25),
('E', 1010, '2022-01-01', 250.00),
('E', 201, '2022-01-02', 50.75),
('E', 301, '2022-01-03', 75.25),
('E', 41, '2022-01-04', 125.50);

INSERT INTO articulos (codigo, descripcion, precio, stock) VALUES
(1, 'Martillo de carpintero', 12.99, 50),
(2, 'Destornillador Phillips', 6.99, 70),
(3, 'Cinta métrica de acero', 8.50, 100),
(4, 'Llave inglesa ajustable', 10.99, 40),
(5, 'Sierra para metales', 18.50, 80),
(6, 'Taladro eléctrico inalámbrico', 79.99, 60),
(7, 'Broca de concreto de 10 mm', 5.99, 120),
(8, 'Pala de jardín', 14.99, 30),
(9, 'Cincel para tallar madera', 9.99, 90),
(10, 'Guantes de trabajo resistentes', 12.99, 40),
(11, 'Llave de tubo de 12 pulgadas', 14.50, 70),
(12, 'Serrucho de mano', 16.99, 50),
(13, 'Clavos galvanizados de 2 pulgadas', 7.99, 110),
(14, 'Pistola de silicona caliente', 11.99, 20),
(15, 'Escalera de aluminio de 6 pies', 39.99, 60),
(16, 'Tornillos para madera de 2-1/2 pulgadas', 9.50, 80),
(17, 'Candado de seguridad resistente', 8.99, 100),
(18, 'Pintura en aerosol color negro mate', 5.99, 30),
(19, 'Flexómetro retráctil de 5 metros', 12.50, 70),
(20, 'Cepillo de alambre de acero', 7.99, 90);

show tables;
describe clientes;
describe facturas;
describe articulos;
select * from clientes;
select * from facturas;
select * from articulos;

drop table if exists morosos;
create table morosos(
	nombre varchar(20),
    apellido varchar(20)
);

insert into morosos values 
	('Carlos','López'),('Diego','Perez'),
	('Juan','Pérez'),('Laura','Torres');
insert into morosos values ('Ana','Hernandez');
select * from morosos;

-- Listar todos los clientes que no son morosos

select * from clientes where nombre='Carlos' and apellido='López';		-- id=3
select * from clientes where nombre='Diego' and apellido='Perez';		-- no existe
select * from clientes where nombre='Juan' and apellido='Pérez'; 		-- id=1
select * from clientes where nombre='Laura' and apellido='Torres'; 		-- no existe
-- existen 2 morosos

select * from clientes;						-- hay 63 clientes
select count(*) cantidad from clientes;		-- hay 63 clientes

-- resta de consultas
-- select * from clientes 
-- 	where nombre not in(select nombre from morosos) 
--    and apellido not in(select apellido from morosos);

-- solución, todavía no estudiamos JOIN
SELECT * FROM clientes c LEFT JOIN morosos m
ON c.nombre = m.nombre AND c.apellido = m.apellido
WHERE m.nombre IS NULL AND m.apellido IS NULL;

-- Gustavo (más optima)
SELECT *
FROM clientes
WHERE (nombre, apellido) NOT IN (SELECT nombre, apellido FROM morosos);

-- chat GPT
SELECT nombre, apellido, direccion
FROM clientes
WHERE CONCAT(nombre, apellido) NOT IN (
    SELECT CONCAT(nombre, apellido)
    FROM morosos
);

-- valores null (desconocido)
insert into clientes (nombre,apellido,direccion) values 
	('Ana','Mendoza',null),('David','Garcia','');

insert into articulos (codigo,descripcion,precio) values
	(5001,'Lampara led 10W',null),(5002,'Lampara led 8W',0);

select * from clientes where direccion is null;
select * from clientes where direccion is not null;
-- select * from clientes where direccion =null;
select * from clientes where direccion='';

insert into clientes (nombre,apellido) values
('Mario','Rodriguez'), ('Marta','Rodriguez'), 
('Mariano','Rodriguez'), ('Marcia','Rodriguez'), 
('Magali','Rodriguez'), ('Micaela','Rodriguez'), 
('Monica','Rodriguez'), ('Mercedes','Rodriguez'), 
('Melina','Rodriguez'), ('Omar','Rodriguez'),
('Mirta','Rodriguez'), ('Armando','Rodriguez'), 
('Maria','Rodriguez'), ('Marcela','Rodriguez');
insert into clientes (nombre,apellido,direccion) values 
('Andres','Perez','av. Lima 345');

-- busqueda de expresiones
-- uso de like y not like
select * from clientes where nombre like 'm%';
select * from clientes where nombre not like 'm%';
select * from clientes where nombre like 'ma%';
select * from clientes where nombre like 'mar%';
select * from clientes where nombre like '%a';
select * from clientes where nombre like '%ar%';
select * from clientes where nombre like 'm%a';
select * from clientes where nombre like 'a%' and apellido like '%z';
select * from clientes where apellido like '%perez%' and direccion like '%lima%';
select * from clientes where nombre like 'm_r%';		-- autor like '%bor_es%'
select * from clientes where nombre like '___';
select * from clientes where nombre like '____';
select * from clientes where nombre like '_____%';

-- ordenamiento order by
select * from clientes;
select * from clientes order by nombre;
select * from clientes order by nombre asc;
select * from clientes order by nombre desc;
select * from clientes order by apellido,nombre;

select * from facturas order by fecha;





    









    



