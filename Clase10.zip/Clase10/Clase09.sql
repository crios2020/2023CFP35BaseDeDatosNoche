/*
			Clase 09
            
            - Posibles softwares clientes
					1 - MySQL Workbench (Solo MariaDB o MySQL)
                    2 - DBeaver CE	(multiples BDs) https://dbeaver.io/download/
                    3 - VSCode (multiples BDs) Database Client Weijan Chen
                    
			
            - Relaciones entre tablas (Videos entre 58 y 87)
            
            -- Almacenamiento RAM:		Veloz		Caro		Volatil
            -- Almacenamiento HDD: 		Lento		Ecónomico	Persistente
            
            -- Planillas de calcúlo trabajan los datos en RAM
            -- Bases de Datos trabajan los datos en HDD
            
            DER Diagrama Entidad Relación

*/

use negocio;
show tables;
drop table if exists padron;

-- En tabla facturas agregamos el campo clave foranea (Foreign Key) (FK)
alter table facturas add  codigoCliente int;
select * from clientes;
insert into facturas values ('T',1004,curdate(),7800,550);
select * from facturas;
update facturas set codigoCliente=1 where letra='A';
update facturas set codigoCliente=2 where letra='B';
update facturas set codigoCliente=3 where letra='C';
update facturas set codigoCliente=4 where letra='D';
update facturas set codigoCliente=5 where letra='E';
update facturas set codigoCliente=6 where letra='F';
update facturas set codigoCliente=7 where letra='X';
update facturas set codigoCliente=8 where letra='T';

-- Creamos la resctricción de clave foranea
alter table facturas 
	add constraint FK_Facturas_Cliente
    foreign key(codigoCliente)
    references clientes(codigo);
    
-- consulta del producto cartesiano
select * from clientes, facturas limit 100000;
select count(*) cantidad from clientes;				-- 65
select count(*) cantidad from facturas;				-- 49
select 65*49;										-- 3185
select count(*) cantidad from clientes, facturas;	-- 3185

-- consulta del producto relacionado
select * from clientes, facturas where clientes.codigo=facturas.codigoCliente;

-- uso de aleas
select * from clientes c, facturas f where c.codigo=f.codigoCliente;

-- uso del join 
select * from clientes c join facturas f on c.codigo=f.codigoCliente;

-- left join
select * from clientes c left join facturas f on c.codigo=f.codigoCliente;

-- right join
select * from clientes c right join facturas f on c.codigo=f.codigoCliente;

-- Ejemplo de uso del join
-- facturas del cliente 'María' 'Gomez'?
select letra, numero, fecha, monto 
	from clientes c join facturas f on c.codigo=f.codigoCliente
	where nombre='María' and apellido='Gomez';

-- Quienes compraron en el día de hoy?
select distinct codigo, nombre, apellido
	from clientes c join facturas f on c.codigo=f.codigoCliente
    where fecha=curdate();

insert into facturas values ('x',2300,curdate(),8000,8);