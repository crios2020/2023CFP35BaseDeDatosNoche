-- Usando la base de datos Libros responder la siguientes consultas.

-- 1- Que libros (codigo,titulo,autor) se le prestaron a cada socio.
-- 2- Lista de socios (documento,nombre,domicilio) que se le presto libros de 'java' (like '%java%')
-- 3- Lista de libros (codigo,titulo,autor) que no fueron devueltos (fechadevolucion is null)
-- 4- Lista de socios (documento,nombre,domicilio) que tienen libros sin devolver.
-- 5- Lista de socios (documento,nombre,domicilio) que tienen libros sin devolver y cuales son los libros.
-- 6- Cantidad de libros sin devolver.
-- 7- Lista de libros que fueron prestados el día de hoy.
-- 8- Cantidad de libros que se prestaron en este mes.
-- 9- Cantidad de libros que fueron prestados en este mes.
-- 10-Cantidad de socios que se le prestaron libres en este mes.

